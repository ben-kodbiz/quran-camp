===================================================================
HUURS STUDIO - FREE OPEN-ACCESS STARTER SUITE
Operating Creed: READ. REFLECT. RETURN.
===================================================================

Contents:
- Surah 01: Al-Fatihah (The Opening) — Complete 10-Plate Suite
- Surah 18: Al-Kahf (The Cave) — Complete 10-Plate Suite
- Surah 67: Al-Mulk (The Dominion) — Complete 10-Plate Suite

Deliverables per Surah:
1. Master Compendium PDF (Cover + TOC + 8 Landscape Plates)
2. Interactive Digital Suite (Offline HTML with search, filtering & deep modals)
3. Vector Mindmap PDF (792x480 pt 16:9 Landscape)
4. Classical Sunni Exegesis Monograph (Tabari, Ibn Kathir, Qurtubi, Razi)
5. Structured Tadabbur Contemplation Guide

License: Personal & Educational Open-Access (Waqf / Sadaqah Jariyah).
Free distribution permitted without modification.
Website: http://localhost:8181/index.html